﻿using static System.Net.Mime.MediaTypeNames;
using System.Xml.Linq;
using System.Windows.Forms;

namespace Acil_Durum
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            panel1 = new Panel();
            lblBaslik = new Label();
            cagriEkleButon = new Button();
            cagriIsleButon = new Button();
            listView1 = new ListView();
            columnHeader1 = new ColumnHeader();
            columnHeader2 = new ColumnHeader();
            columnHeader3 = new ColumnHeader();
            listView2 = new ListView();
            columnHeader4 = new ColumnHeader();
            columnHeader5 = new ColumnHeader();
            columnHeader6 = new ColumnHeader();
            lblBekleyenCagrilar = new Label();
            lblIslenenCagrilar = new Label();
            lblToplamCagri = new Label();
            panel1.SuspendLayout();
            SuspendLayout();

            // panel1
            panel1.BackColor = Color.FromArgb(41, 128, 185);
            panel1.Controls.Add(lblBaslik);
            panel1.Controls.Add(cagriEkleButon);
            panel1.Controls.Add(cagriIsleButon);
            panel1.Controls.Add(lblToplamCagri);
            panel1.Dock = DockStyle.Top;
            panel1.Height = 100;
            panel1.Padding = new Padding(20);

            // lblBaslik
            lblBaslik.AutoSize = true;
            lblBaslik.ForeColor = Color.White;
            lblBaslik.Location = new Point(20, 25);
            lblBaslik.Text = "ACİL DURUM MÜDAHALE SİSTEMİ";

            // cagriEkleButon
            cagriEkleButon.BackColor = Color.FromArgb(46, 204, 113);
            cagriEkleButon.FlatStyle = FlatStyle.Flat;
            cagriEkleButon.ForeColor = Color.White;
            cagriEkleButon.Location = new Point(500, 25);
            cagriEkleButon.Size = new Size(150, 50);
            cagriEkleButon.Text = "YENİ ÇAĞRI";
            cagriEkleButon.UseVisualStyleBackColor = false;
            cagriEkleButon.Click += cagriEkleButon_Click;

            // cagriIsleButon
            cagriIsleButon.BackColor = Color.FromArgb(230, 126, 34);
            cagriIsleButon.FlatStyle = FlatStyle.Flat;
            cagriIsleButon.ForeColor = Color.White;
            cagriIsleButon.Location = new Point(670, 25);
            cagriIsleButon.Size = new Size(150, 50);
            cagriIsleButon.Text = "ÇAĞRIYI İŞLE";
            cagriIsleButon.UseVisualStyleBackColor = false;
            cagriIsleButon.Click += cagriIsleButon_Click;

            // lblToplamCagri
            lblToplamCagri.AutoSize = true;
            lblToplamCagri.ForeColor = Color.White;
            lblToplamCagri.Location = new Point(850, 25);
            lblToplamCagri.Text = "TOPLAM ÇAĞRI: 0\nMÜDAHALE EDİLEN: 0";
            lblToplamCagri.TextAlign = ContentAlignment.MiddleCenter;

            // lblBekleyenCagrilar
            lblBekleyenCagrilar.AutoSize = true;
            lblBekleyenCagrilar.ForeColor = Color.FromArgb(41, 128, 185);
            lblBekleyenCagrilar.Location = new Point(20, 120);
            lblBekleyenCagrilar.Text = "BEKLEYEN ÇAĞRILAR";

            // lblIslenenCagrilar
            lblIslenenCagrilar.AutoSize = true;
            lblIslenenCagrilar.ForeColor = Color.FromArgb(41, 128, 185);
            lblIslenenCagrilar.Location = new Point(20, 400);
            lblIslenenCagrilar.Text = "İŞLENEN ÇAĞRILAR";

            // listView1
            listView1.BackColor = Color.White;
            listView1.Columns.AddRange(new ColumnHeader[] { columnHeader1, columnHeader2, columnHeader3 });
            listView1.FullRowSelect = true;
            listView1.HeaderStyle = ColumnHeaderStyle.Nonclickable;
            listView1.Location = new Point(20, 160);
            listView1.Size = new Size(960, 220);
            listView1.TabIndex = 0;
            listView1.UseCompatibleStateImageBehavior = false;
            listView1.View = View.Details;
            listView1.GridLines = true;

            // columnHeader1
            columnHeader1.Text = "OLAY";
            columnHeader1.Width = 300;

            // columnHeader2
            columnHeader2.Text = "MAHALLE";
            columnHeader2.Width = 300;

            // columnHeader3
            columnHeader3.Text = "EN YAKIN BİRİM";
            columnHeader3.Width = 300;

            // listView2
            listView2.BackColor = Color.White;
            listView2.Columns.AddRange(new ColumnHeader[] { columnHeader4, columnHeader5, columnHeader6 });
            listView2.FullRowSelect = true;
            listView2.HeaderStyle = ColumnHeaderStyle.Nonclickable;
            listView2.Location = new Point(20, 440);
            listView2.Size = new Size(960, 220);
            listView2.TabIndex = 1;
            listView2.UseCompatibleStateImageBehavior = false;
            listView2.View = View.Details;
            listView2.GridLines = true;

            // columnHeader4
            columnHeader4.Text = "OLAY";
            columnHeader4.Width = 300;

            // columnHeader5
            columnHeader5.Text = "MAHALLE";
            columnHeader5.Width = 300;

            // columnHeader6
            columnHeader6.Text = "EN YAKIN BİRİM";
            columnHeader6.Width = 300;

            // Form1
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(240, 244, 247);
            ClientSize = new Size(1000, 680);
            Controls.Add(panel1);
            Controls.Add(lblBekleyenCagrilar);
            Controls.Add(listView1);
            Controls.Add(lblIslenenCagrilar);
            Controls.Add(listView2);
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Acil Durum Müdahale Sistemi";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        private Panel panel1;
        private Label lblBaslik;
        private Button cagriEkleButon;
        private Button cagriIsleButon;
        private ListView listView1;
        private ColumnHeader columnHeader1;
        private ColumnHeader columnHeader2;
        private ColumnHeader columnHeader3;
        private ListView listView2;
        private ColumnHeader columnHeader4;
        private ColumnHeader columnHeader5;
        private ColumnHeader columnHeader6;
        private Label lblBekleyenCagrilar;
        private Label lblIslenenCagrilar;
        private Label lblToplamCagri;
    }
}