﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Acil_Durum
{
    public class AcilDurum
    {
        public string OlayTipi { get; set; }
        public string Mahalle { get; set; }
        public int Aciliyet { get; set; }
        public string Birim { get; set; }
        public int Oncelik { get; set; }

        public AcilDurum(string olay, string mahalle, int aciliyet, string birim)
        {
            OlayTipi = olay;
            Mahalle = mahalle;
            Aciliyet = aciliyet;
            Birim = birim;
        }

        public override string ToString()
        {
            return $"{OlayTipi.ToUpper()} - {Mahalle} ({Aciliyet}) → En yakın birim: {Birim}";
        }
    }

    public class MinHeap
    {
        private List<AcilDurum> heap;

        public MinHeap()
        {
            heap = new List<AcilDurum>();
        }

        public int Count => heap.Count;

        public void Ekle(AcilDurum cagri)
        {
            heap.Add(cagri);
            YukariTasi(heap.Count - 1);
        }

        public AcilDurum CikarMin()
        {
            if (heap.Count == 0)
                throw new InvalidOperationException("Heap boş");

            AcilDurum min = heap[0];
            heap[0] = heap[heap.Count - 1];
            heap.RemoveAt(heap.Count - 1);

            if (heap.Count > 0)
                AsagiTasi(0);

            return min;
        }

        private void YukariTasi(int index)
        {
            while (index > 0)
            {
                int ebeveyn = (index - 1) / 2;
                if (heap[index].Aciliyet >= heap[ebeveyn].Aciliyet)
                    break;
                Degistir(index, ebeveyn);
                index = ebeveyn;
            }
        }

        private void AsagiTasi(int index)
        {
            while (true)
            {
                int minIndex = index;
                int sol = 2 * index + 1;
                int sag = 2 * index + 2;

                if (sol < heap.Count && heap[sol].Aciliyet < heap[minIndex].Aciliyet)
                    minIndex = sol;

                if (sag < heap.Count && heap[sag].Aciliyet < heap[minIndex].Aciliyet)
                    minIndex = sag;

                if (minIndex == index)
                    break;

                Degistir(index, minIndex);
                index = minIndex;
            }
        }

        private void Degistir(int i, int j)
        {
            AcilDurum temp = heap[i];
            heap[i] = heap[j];
            heap[j] = temp;
        }

        public List<AcilDurum> GetirTumunu()
        {
            return heap.OrderBy(x => x.Aciliyet).ToList();
        }
    }

    public class AcilDurumKuyrugu
    {
        private Queue<AcilDurum> kuyruk;

        public AcilDurumKuyrugu()
        {
            kuyruk = new Queue<AcilDurum>();
        }

        public int Count => kuyruk.Count;

        public void Ekle(AcilDurum cagri)
        {
            kuyruk.Enqueue(cagri);
        }

        public List<AcilDurum> GetirTumunu()
        {
            return kuyruk.ToList();
        }
    }

    public class Agirlikli_Yonsuz_Graf
    {
        private Dictionary<string, Dictionary<string, int>> komsuluk;

        public Agirlikli_Yonsuz_Graf()
        {
            komsuluk = new Dictionary<string, Dictionary<string, int>>();
        }

        public void Kenar_Ekle(string dugum1, string dugum2, int agirlik)
        {
            if (!komsuluk.ContainsKey(dugum1.ToLower()))
                komsuluk[dugum1.ToLower()] = new Dictionary<string, int>();
            if (!komsuluk.ContainsKey(dugum2.ToLower()))
                komsuluk[dugum2.ToLower()] = new Dictionary<string, int>();

            komsuluk[dugum1.ToLower()][dugum2.ToLower()] = agirlik;
            komsuluk[dugum2.ToLower()][dugum1.ToLower()] = agirlik;
        }

        public class Oncelikli_Kuyruk<T>
        {
            private List<(T item, int priority)> elements = new List<(T, int)>();
            public int Count => elements.Count;

            public void Enqueue(T item, int priority)
            {
                elements.Add((item, priority));
            }
            public bool TryDequeue(out T item, out int priority)
            {
                if (elements.Count == 0)
                {
                    item = default(T);
                    priority = default(int);
                    return false;
                }
                int bestIndex = 0;
                for (int i = 1; i < elements.Count; i++)
                {
                    if (elements[i].priority < elements[bestIndex].priority)
                    {
                        bestIndex = i;
                    }
                }
                (item, priority) = elements[bestIndex];
                elements.RemoveAt(bestIndex);
                return true;
            }
        }

        public Dictionary<string, int> Dijkstra(string baslangic)
        {
            var mesafeler = new Dictionary<string, int>();
            var oncekiler = new Dictionary<string, string>();
            var kuyruk = new Oncelikli_Kuyruk<string>();

            foreach (var dugum in komsuluk.Keys)
            {
                mesafeler[dugum] = int.MaxValue;
            }

            baslangic = baslangic.ToLower();
            mesafeler[baslangic] = 0;
            kuyruk.Enqueue(baslangic, 0);

            while (kuyruk.Count > 0)
            {
                kuyruk.TryDequeue(out string mevcut, out int mevcutMesafe);

                foreach (var komsu in komsuluk[mevcut])
                {
                    int yeniMesafe = mesafeler[mevcut] + komsu.Value;

                    if (yeniMesafe < mesafeler[komsu.Key])
                    {
                        mesafeler[komsu.Key] = yeniMesafe;
                        kuyruk.Enqueue(komsu.Key, yeniMesafe);
                        oncekiler[komsu.Key] = mevcut;
                    }
                }
            }
            return mesafeler;
        }
    }
}