using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using System.Linq;
using Acil_Durum;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Acil_Durum
{
    public partial class Form1 : Form
    {
        private Agirlikli_Yonsuz_Graf graph = new Agirlikli_Yonsuz_Graf();
        private MinHeap minHeap = new MinHeap();
        private Queue<AcilDurum> islenenCagrilar = new Queue<AcilDurum>();
        private AcilDurumKuyrugu islenenKuyruk = new AcilDurumKuyrugu();
        private System.Windows.Forms.Timer timer;

        string[] mahalleler = { "Görükle", "19 Mayıs", "Özlüce", "Yüzüncüyıl", "29 Ekim", "Altınşehir", "Üçevler", "Ataevler", "Beşevler", "Demirci" };
        string[] olaylar = { "yangın", "trafik kazası", "cinayet", "diğer", "yaralanma" };

        Dictionary<string, int> olayAciliyet = new Dictionary<string, int>()
        {
            {"cinayet", 1 },
            {"yangın", 2 },
            {"trafik kazası", 3 },
            {"yaralanma", 4 },
            {"diğer", 5 },
        };

        Random rnd = new Random();

        public Form1()
        {
            InitializeComponent();
            grafiKur();
            SetupTimer();
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
        }

        private void SetupTimer()
        {
            timer = new System.Windows.Forms.Timer();
            timer.Interval = 3000; // 3 saniye
            timer.Tick += Timer_Tick;
            timer.Start();
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            if (minHeap.Count > 0)
            {
                cagriIsleButon.BackColor = Color.FromArgb(230, 126, 34);
                cagriIsleButon.ForeColor = Color.White;
            }
            else
            {
                cagriIsleButon.BackColor = Color.FromArgb(189, 195, 199);
                cagriIsleButon.ForeColor = Color.FromArgb(127, 140, 141);
            }
        }

        private void grafiKur()
        {
            graph.Kenar_Ekle("Görükle", "19 Mayıs", 120);
            graph.Kenar_Ekle("Görükle", "Özlüce", 140);
            graph.Kenar_Ekle("19 Mayıs", "Özlüce", 60);
            graph.Kenar_Ekle("19 Mayıs", "Yüzüncüyıl", 40);
            graph.Kenar_Ekle("Özlüce", "Yüzüncüyıl", 90);
            graph.Kenar_Ekle("Özlüce", "1.Acil Birimi", 30);
            graph.Kenar_Ekle("Özlüce", "29 Ekim", 100);
            graph.Kenar_Ekle("Özlüce", "Altınşehir", 100);
            graph.Kenar_Ekle("Yüzüncüyıl", "1.Acil Birimi", 10);
            graph.Kenar_Ekle("Yüzüncüyıl", "29 Ekim", 30);
            graph.Kenar_Ekle("Üçevler", "2.Acil Birimi", 40);
            graph.Kenar_Ekle("Üçevler", "Ataevler", 70);
            graph.Kenar_Ekle("Üçevler", "Beşevler", 60);
            graph.Kenar_Ekle("Üçevler", "Demirci", 40);
            graph.Kenar_Ekle("29 Ekim", "Altınşehir", 70);
            graph.Kenar_Ekle("29 Ekim", "1.Acil Birimi", 15);
            graph.Kenar_Ekle("29 Ekim", "Üçevler", 100);
            graph.Kenar_Ekle("Altınşehir", "Üçevler", 80);
            graph.Kenar_Ekle("Altınşehir", "Ataevler", 110);
            graph.Kenar_Ekle("Altınşehir", "2.Acil Birimi", 50);
            graph.Kenar_Ekle("Ataevler", "2.Acil Birimi", 30);
            graph.Kenar_Ekle("Ataevler", "Beşevler", 40);
        }

        private void cagriEkleButon_Click(object sender, EventArgs e)
        {
            string mahalle = mahalleler[rnd.Next(mahalleler.Length)];
            string olay = olaylar[rnd.Next(olaylar.Length)];
            int aciliyet = olayAciliyet[olay];

            var mesafeler = graph.Dijkstra(mahalle);
            int m1 = mesafeler.ContainsKey("1.acil birimi") ? mesafeler["1.acil birimi"] : int.MaxValue;
            int m2 = mesafeler.ContainsKey("2.acil birimi") ? mesafeler["2.acil birimi"] : int.MaxValue;
            string birim = (m1 <= m2) ? "1.Acil Birimi" : "2.Acil Birimi";

            AcilDurum cagri = new AcilDurum(olay, mahalle, aciliyet, birim);
            minHeap.Ekle(cagri);
            ListeyiGuncelle();
        }

        private void cagriIsleButon_Click(object sender, EventArgs e)
        {
            if (minHeap.Count > 0)
            {
                var cagri = minHeap.CikarMin();
                islenenKuyruk.Ekle(cagri);
                ListeyiGuncelle();
            }
            else
            {
                MessageBox.Show("Bekleyen çağrı yok.", "UYARI", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

        }

        private void ListeyiGuncelle()
        {
            listView1.Items.Clear();
            foreach (var cagri in minHeap.GetirTumunu())
            {
                ListViewItem item = new ListViewItem(new[] { cagri.OlayTipi.ToUpper(), cagri.Mahalle, cagri.Birim });

                switch (cagri.Aciliyet)
                {
                    case 1: // Cinayet - Koyu kırmızı
                        item.BackColor = Color.FromArgb(179, 0, 0);  // Kan kırmızısı
                        item.ForeColor = Color.White;
                        break;
                    case 2: // Yangın - Turuncu
                        item.BackColor = Color.FromArgb(255, 87, 34);  // Derin turuncu
                        item.ForeColor = Color.White;
                        break;
                    case 3: // Trafik Kazası - Sarı
                        item.BackColor = Color.FromArgb(255, 193, 7);  // Amber sarı
                        item.ForeColor = Color.Black;
                        break;
                    case 4: // Yaralanma - Mor
                        item.BackColor = Color.FromArgb(142, 36, 170);  // Mor
                        item.ForeColor = Color.White;
                        break;
                    case 5: // Diğer - Teal
                        item.BackColor = Color.FromArgb(0, 150, 136);  // Teal
                        item.ForeColor = Color.White;
                        break;
                }

                listView1.Items.Add(item);
            }

            listView2.Items.Clear();
            foreach (var cagri in islenenKuyruk.GetirTumunu())
            {
                ListViewItem item = new ListViewItem(new[] { cagri.OlayTipi.ToUpper(), cagri.Mahalle, cagri.Birim });
                item.BackColor = Color.FromArgb(236, 240, 241);
                item.ForeColor = Color.FromArgb(44, 62, 80);
                listView2.Items.Add(item);
            }

            int toplamCagri = islenenKuyruk.Count + minHeap.Count;
            int mudahaleEdilenCagri = islenenKuyruk.Count;
            lblToplamCagri.Text = $"TOPLAM ÇAĞRI: {toplamCagri}\nMÜDAHALE EDİLEN: {mudahaleEdilenCagri}";
        }
    }
}